#!/bin/bash

#SBATCH -p palamut-cuda
#SBATCH -M truba
#SBATCH -A omalcioglu
#SBATCH -J vasp-test
#SBATCH --ntasks-per-node=16
#SBATCH --gres=gpu:8
#SBATCH --time=48:00:00
#SBATCH -N 1
#SBATCH -n 8
#SBATCH -c 16
#SBATCH --output=slurm-%j.out
#SBATCH --error=slurm-%j.err


#echo "SLURM_NODELIST $SLURM_NODELIST"
#echo "NUMBER OF CORES $SLURM_NTASKS"

#export OMP_NUM_THREADS=1

source /truba/sw/centos7.3/comp/intel/PS2018-update2/bin/compilervars.sh intel64


module load centos7.9/comp/pgi/2021_213/nvhpc/21.3 generic/vasp/nvhpc/6.2-openACC

WORKPATH="/truba_scratch/omalcioglu/tugberkozdemir/hf-test"
OUTPATH="/truba/home/omalcioglu/tugberkozdemir/outputs-hf-af2-04.07"

x="x"
np=8
echo "$(tput setaf 7)$(tput setab 3) HF@LDA (GPU, forever-diamond) $(tput sgr 0)"
echo ""

for k in 3 5 7 9 11 13
do
        for i in 3.5 3.6 3.7 3.8 3.9 4.0 4.1 4.2 4.3 4.4 4.5
        do
                for mag in AF2
                do
                        rm -rf $WORKPATH/PLAYGROUND
                        rm -rf $WORKPATH/STORAGE
                        mkdir -p $WORKPATH/PLAYGROUND
                        mkdir -p $WORKPATH/STORAGE


                        mkdir -p $OUTPATH/$mag/LDA/$i/HF

                        # Pre-converged DFT

                        # Bring POTCAR to the PLAYGROUND:
                        cp resources/POTCAR.LDA  $WORKPATH/PLAYGROUND/POTCAR

                        # Bring POSCAR to the PLAYGROUND:
                        cp resources/POSCAR-$mag-$i.vasp $WORKPATH/PLAYGROUND/POSCAR

                        # Bring appropriate KPOINTS file to the PLAYGROUND
                        cp resources/KPOINTS.$k        $WORKPATH/PLAYGROUND/KPOINTS


                        touch  $WORKPATH/PLAYGROUND/INCAR


                        if [ $mag == "AF1" ]
                        then
                                echo -e "SYSTEM = NiO-AF1-GROUNDSTATE\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        if [ $mag == "AF2" ]
                        then
                                echo -e "SYSTEM = NiO-AF2-GROUNDSTATE\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        if [ $mag == "FM" ]
                        then
                                echo -e "SYSTEM = NiO-FM-GROUNDSTATE\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        echo -e "EDIFF = 1E-8\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "PREC = Accurate\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "KPAR = 8\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "NSIM = 16\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "ALGO = ALL\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "NELM = 150\n" >> $WORKPATH/PLAYGROUND/INCAR



                        echo -e "ENCUT = 600\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "ENAUG = 1200\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "ISMEAR = 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "SIGMA = 0.01\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "LMAXMIX = 4\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "LASPH = .TRUE.\n" >> $WORKPATH/PLAYGROUND/INCAR

                      echo -e "ISPIN = 2\n" >> $WORKPATH/PLAYGROUND/INCAR

                      if [ $mag == "AF1" ]
                      then
                              echo -e "MAGMOM = 2 -2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi

                      if [ $mag == "AF2" ]
                      then
                              echo -e "MAGMOM = 2 -2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi

                      if [ $mag == "FM" ]
                      then
                              echo -e "MAGMOM = 2 2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi


                      # Fire it up
                      echo "$(tput setaf 4)$(tput setab 2) Starting DFT ($mag, a=$i, $k$x$k$x$k)... $(tput sgr 0)"
                      start=`date +%s`
                      mpirun --mca btl self,tcp -np $np -wdir $WORKPATH/PLAYGROUND vasp_std
                      end=`date +%s`
                      runtime=$((end - start))
                      echo "$(tput setaf 7)$(tput setab 4) DFT took $runtime seconds. $(tput sgr 0)"
                      echo "$(tput setaf 4)$(tput setab 2) Finished DFT... $(tput sgr 0)"

                      cp      $WORKPATH/PLAYGROUND/INCAR      $OUTPATH/$mag/LDA/$i/HF/INCAR.DFT
                      cp      $WORKPATH/PLAYGROUND/POSCAR     $OUTPATH/$mag/LDA/$i/HF/
                      cp      $WORKPATH/PLAYGROUND/KPOINTS    $OUTPATH/$mag/LDA/$i/HF/KPOINTS.$k
                      cp      $WORKPATH/PLAYGROUND/OUTCAR     $OUTPATH/$mag/LDA/$i/HF/OUTCAR.DFT.$k$x$k$x$k



                      rm $WORKPATH/PLAYGROUND/INCAR
                      touch $WORKPATH/PLAYGROUND/INCAR

                      if [ $mag == "AF1" ]
                      then
                              echo -e "SYSTEM = NiO-AF1-HF\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi

                      if [ $mag == "AF2" ]
                      then
                              echo -e "SYSTEM = NiO-AF2-HF\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi

                      if [ $mag == "FM" ]
                      then
                              echo -e "SYSTEM = NiO-FM-HF\n" >> $WORKPATH/PLAYGROUND/INCAR
                      fi

                      echo -e "KPAR = 8\n" >> $WORKPATH/PLAYGROUND/INCAR
                      echo -e "NSIM = 16\n" >> $WORKPATH/PLAYGROUND/INCAR


                      echo -e "ALGO = EIGENVAL\n" >> $WORKPATH/PLAYGROUND/INCAR


                      echo -e "NELM = 1\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "LHFCALC = .TRUE.\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "AEXX = 1.0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "ALDAC = 0.0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "AGGAC = 0.0\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "EDIFF = 1E-8\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "PREC = Acurate\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "ENCUT = 600\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "ENAUG = 1200\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "ISMEAR = 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        echo -e "SIGMA = 0.01\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "LMAXMIX = 4\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "LASPH = .TRUE.\n" >> $WORKPATH/PLAYGROUND/INCAR

                        echo -e "ISPIN = 2\n" >> $WORKPATH/PLAYGROUND/INCAR

                        if [ $mag == "AF1" ]
                        then
                                echo -e "MAGMOM = 2 -2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        if [ $mag == "AF2" ]
                        then
                                echo -e "MAGMOM = 2 -2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        if [ $mag == "FM" ]
                        then
                                echo -e "MAGMOM = 2 2 0 0\n" >> $WORKPATH/PLAYGROUND/INCAR
                        fi

                        # Fire it up
                       echo "$(tput setaf 4)$(tput setab 2) Starting HF ($mag, a=$i, $k$x$k$x$k)... $(tput sgr 0)"
                       start=`date +%s`
                       mpirun --mca btl self,tcp  -np $np -wdir $WORKPATH/PLAYGROUND vasp_std
                       end=`date +%s`
                       runtime=$((end - start))
                       echo "$(tput setaf 7)$(tput setab 4) HF took $runtime seconds. $(tput sgr 0)"
                       echo "$(tput setaf 4)$(tput setab 2) Finished HF... $(tput sgr 0)"

                       cp      $WORKPATH/PLAYGROUND/INCAR      $OUTPATH/$mag/LDA/$i/HF/INCAR.HF
                       cp      $WORKPATH/PLAYGROUND/OUTCAR     $OUTPATH/$mag/LDA/$i/HF/OUTCAR.HF.$k$x$k$x$k

               done ## end of each magnetism
       done # end of various lattice parameters
done ## end of kpoints
